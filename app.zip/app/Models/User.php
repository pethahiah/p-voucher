<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'name',
        'email',
        'email_verified_at',
        'password',
        'otp',
        'phone',
        'first_name',
        'middle_name',
        'last_name',
        'address',
        'state',
        'country',
        'city',
        'image',
        'usertype',
        'registration_code',
        'company_name',
        'nimc',
        'bvn',
        'face_image',
        'lga_of_origin',
        'age',
        'gender',
        'longitude',
        'latitude',
        'isVerified',
    ];


    public function merchants(): \Illuminate\Database\Eloquent\Relations\HasMany
    {
        return $this->hasMany(Merchant::class);
    }

    public function sponsor(): \Illuminate\Database\Eloquent\Relations\HasOne
    {
        return $this->hasOne(Sponsor::class);
    }


    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];
}
